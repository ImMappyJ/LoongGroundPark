#ifndef MACRODEFINE_H
#define MACRODEFINE_H

#define STATUS_OK 1
#define STATUS_ERROR 0
#define COLOR_OCCUPIED "red"
#define COLOR_ORDER "orange"
#define COLOR_FREE "green"

#endif // MACRODEFINE_H
