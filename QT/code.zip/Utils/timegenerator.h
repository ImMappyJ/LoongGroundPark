#ifndef TIMEGENERATOR_H
#define TIMEGENERATOR_H
#include <QString>
#include <QDateTime>
#include <ctime>

long int get_now_time();
QString get_now_time_str();

#endif // TIMEGENERATOR_H
